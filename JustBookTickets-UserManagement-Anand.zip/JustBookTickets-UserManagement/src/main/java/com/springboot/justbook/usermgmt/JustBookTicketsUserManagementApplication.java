package com.springboot.justbook.usermgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JustBookTicketsUserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(JustBookTicketsUserManagementApplication.class, args);
	}

}
