/**
 * 
 */
package com.springboot.justbook.usermgmt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springboot.justbook.usermgmt.domain.UserDetails;

/**
 * @author M1006601
 *
 */
public interface UserMgmtRepository extends JpaRepository<UserDetails, Long>{
	

	@Query(nativeQuery=true, value="Select * from user_details where user_details_user_name=:userDetailsUserName and user_details_email=:userDetailsEmail")
	UserDetails findbyUserNameAndEmail(String userDetailsUserName, String userDetailsEmail);

	@Query(nativeQuery=true, value="Select * from user_details where user_details_user_name=:username")
	UserDetails findbyUserName(String username);

}
