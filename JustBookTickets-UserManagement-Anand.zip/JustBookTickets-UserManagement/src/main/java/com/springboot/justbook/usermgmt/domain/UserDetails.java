/**
 * 
 */
package com.springboot.justbook.usermgmt.domain;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


/**
 * @author M1006601
 *
 */
@Entity
@Table(name="user_details")
public class UserDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_details_id")
	private Long userDetailsId;
	
	@NotNull
	@NotEmpty
	@Size(min = 6)
	@Column(name="user_details_fname")
	private String userDetailsFName;
	
	@Column(name="user_details_lname")
	private String userDetailsLName;
	
	@NotNull
	@NotEmpty
	@Size(min = 8)
	@Pattern(regexp="^[A-Za-z0-9@.]*$")
	@Column(name="user_details_user_name")
	private String userDetailsUserName;
	
	@NotNull
	@Email
	@NotEmpty
	@Column(name="user_details_email")
	private String userDetailsEmail;
	
	@NotBlank
	@NotEmpty
	@NotNull
	@Size(min = 8)
	@Column(name="user_details_password")
	private String userDetailsPassword;
	
	@NotNull
	@Pattern(regexp="(^$|[0-9]{10})")
	@Column(name="user_details_phoneNo")
	private String userDetailsPhoneNo;
	
	@Size(max = 200)
	@Column(name="user_details_address")
	@NotEmpty
	private String userDetailsAddress;

	/**
	 * @param userDetailsId
	 * @param userDetailsFName
	 * @param userDetailsLName
	 * @param userDetailsUserName
	 * @param userDetailsEmail
	 * @param userDetailsPassword
	 * @param userDetailsPhoneNo
	 * @param userDetailsAddress
	 */
	public UserDetails(Long userDetailsId, String userDetailsFName,	String userDetailsLName,
			String userDetailsUserName,	String userDetailsEmail, String userDetailsPassword,
			String userDetailsPhoneNo, String userDetailsAddress) {
		super();
		this.userDetailsId = userDetailsId;
		this.userDetailsFName = userDetailsFName;
		this.userDetailsLName = userDetailsLName;
		this.userDetailsUserName = userDetailsUserName;
		this.userDetailsEmail = userDetailsEmail;
		this.userDetailsPassword = userDetailsPassword;
		this.userDetailsPhoneNo = userDetailsPhoneNo;
		this.userDetailsAddress = userDetailsAddress;
	}
	
	public UserDetails() {
	}

	/**
	 * @return the userDetailsId
	 */
	public Long getUserDetailsId() {
		return userDetailsId;
	}

	/**
	 * @param userDetailsId the userDetailsId to set
	 */
	public void setUserDetailsId(Long userDetailsId) {
		this.userDetailsId = userDetailsId;
	}

	/**
	 * @return the userDetailsFName
	 */
	public String getUserDetailsFName() {
		return userDetailsFName;
	}

	/**
	 * @param userDetailsFName the userDetailsFName to set
	 */
	public void setUserDetailsFName(String userDetailsFName) {
		this.userDetailsFName = userDetailsFName;
	}

	/**
	 * @return the userDetailsLName
	 */
	public String getUserDetailsLName() {
		return userDetailsLName;
	}

	/**
	 * @param userDetailsLName the userDetailsLName to set
	 */
	public void setUserDetailsLName(String userDetailsLName) {
		this.userDetailsLName = userDetailsLName;
	}

	/**
	 * @return the userDetailsUserName
	 */
	public String getUserDetailsUserName() {
		return userDetailsUserName;
	}

	/**
	 * @param userDetailsUserName the userDetailsUserName to set
	 */
	public void setUserDetailsUserName(String userDetailsUserName) {
		this.userDetailsUserName = userDetailsUserName;
	}

	/**
	 * @return the userDetailsEmail
	 */
	public String getUserDetailsEmail() {
		return userDetailsEmail;
	}

	/**
	 * @param userDetailsEmail the userDetailsEmail to set
	 */
	public void setUserDetailsEmail(String userDetailsEmail) {
		this.userDetailsEmail = userDetailsEmail;
	}

	/**
	 * @return the userDetailsPassword
	 */
	public String getUserDetailsPassword() {
		return userDetailsPassword;
	}

	/**
	 * @param userDetailsPassword the userDetailsPassword to set
	 */
	public void setUserDetailsPassword(String userDetailsPassword) {
		this.userDetailsPassword = userDetailsPassword;
	}

	/**
	 * @return the userDetailsPhoneNo
	 */
	public String getUserDetailsPhoneNo() {
		return userDetailsPhoneNo;
	}

	/**
	 * @param userDetailsPhoneNo the userDetailsPhoneNo to set
	 */
	public void setUserDetailsPhoneNo(String userDetailsPhoneNo) {
		this.userDetailsPhoneNo = userDetailsPhoneNo;
	}

	/**
	 * @return the userDetailsAddress
	 */
	public String getUserDetailsAddress() {
		return userDetailsAddress;
	}

	/**
	 * @param userDetailsAddress the userDetailsAddress to set
	 */
	public void setUserDetailsAddress(String userDetailsAddress) {
		this.userDetailsAddress = userDetailsAddress;
	}

	@Override
	public int hashCode() {
		return Objects.hash(userDetailsEmail, userDetailsUserName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDetails other = (UserDetails) obj;
		return Objects.equals(userDetailsEmail, other.userDetailsEmail)
				&& Objects.equals(userDetailsUserName, other.userDetailsUserName);
	}
	
	
}
