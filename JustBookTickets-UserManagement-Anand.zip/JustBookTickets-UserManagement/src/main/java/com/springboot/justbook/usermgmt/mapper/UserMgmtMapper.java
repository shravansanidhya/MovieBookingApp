/**
 * 
 */
package com.springboot.justbook.usermgmt.mapper;

import org.springframework.stereotype.Component;

import com.springboot.justbook.usermgmt.domain.UserDetails;
import com.springboot.justbook.usermgmt.vo.UserDetailsRequestVO;
import com.springboot.justbook.usermgmt.vo.UserDetailsResponseVO;

/**
 * @author M1006601
 *
 */
@Component
public class UserMgmtMapper {
	
	public UserDetails mapRequestVOToDomain(UserDetailsRequestVO requestVO) throws Exception{
		
		UserDetails userDetails = new UserDetails();
		userDetails.setUserDetailsFName(requestVO.getUserDetailsFName());
		userDetails.setUserDetailsLName(requestVO.getUserDetailsLName());
		userDetails.setUserDetailsUserName(requestVO.getUserDetailsUserName());
		userDetails.setUserDetailsEmail(requestVO.getUserDetailsEmail());
		userDetails.setUserDetailsAddress(requestVO.getUserDetailsAddress());
		userDetails.setUserDetailsPhoneNo(requestVO.getUserDetailsPhoneNo());
		userDetails.setUserDetailsPassword(requestVO.getUserDetailsPassword());
		return userDetails;		
	}

	public UserDetailsResponseVO mapDomainToResponseVo(UserDetails userDetails) {
		
		UserDetailsResponseVO userResponse = new UserDetailsResponseVO();
		userResponse.setUserDetailsEmail(userDetails.getUserDetailsEmail());
		userResponse.setUserDetailsPhoneNo(userDetails.getUserDetailsPhoneNo());
		userResponse.setUserDetailsUserName(userDetails.getUserDetailsUserName());
		userResponse.setUserDetailsPassword(userDetails.getUserDetailsPassword());
		userResponse.setUserDetailsId(userDetails.getUserDetailsId());
		return userResponse;
	}
	
	
}
