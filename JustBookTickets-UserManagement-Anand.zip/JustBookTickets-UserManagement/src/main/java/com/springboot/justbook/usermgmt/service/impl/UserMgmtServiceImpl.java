/**
 * 
 */
package com.springboot.justbook.usermgmt.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.springboot.justbook.usermgmt.domain.UserDetails;
import com.springboot.justbook.usermgmt.mapper.UserMgmtMapper;
import com.springboot.justbook.usermgmt.repository.UserMgmtRepository;
import com.springboot.justbook.usermgmt.service.UserMgmtService;
import com.springboot.justbook.usermgmt.vo.ResponseObject;
import com.springboot.justbook.usermgmt.vo.UserDetailsRequestVO;
import com.springboot.justbook.usermgmt.vo.UserDetailsResponseVO;

/**
 * @author M1006601
 *
 */
@Service
public class UserMgmtServiceImpl implements UserMgmtService {
	
	@Autowired
	UserMgmtRepository userRepository;
	
	@Autowired
	UserMgmtMapper mapper;

	@Override
	public ResponseObject addNewUser(UserDetailsRequestVO user) throws Exception {
		
		UserDetails existingUser = userRepository.findbyUserNameAndEmail(user.getUserDetailsUserName(), user.getUserDetailsEmail());
		ResponseObject responseObj = new ResponseObject();
		if (null == existingUser || ObjectUtils.isEmpty(existingUser)) {
			UserDetails userDetails = mapper.mapRequestVOToDomain(user);
			List<UserDetailsResponseVO> userDetailsResponseVOList = new ArrayList<UserDetailsResponseVO>();
			userRepository.save(userDetails);
			Long userID = userDetails.getUserDetailsId();
			responseObj.setId(userID);
			userDetailsResponseVOList.add(mapper.mapDomainToResponseVo(userDetails));
			responseObj.setResultList(userDetailsResponseVOList);
		}else {
			responseObj.setErrorCode("invalidUserDetails");
			responseObj.setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
			responseObj.setDescription("User already exists, try logging in...!");
		}
		
		return responseObj;
	}

	@Override
	public ResponseObject getUserDetails(String username) {
		
		UserDetails user = userRepository.findbyUserName(username);
		ResponseObject responseObj = new ResponseObject();
		if(null!=user) {
			List<UserDetailsResponseVO> userDetailsResponseVOList = new ArrayList<UserDetailsResponseVO>();
			userDetailsResponseVOList.add(mapper.mapDomainToResponseVo(user));
			Long userID = user.getUserDetailsId();
			responseObj.setId(userID);
			responseObj.setResultList(userDetailsResponseVOList);
		}else {
			responseObj.setErrorCode("invalidUserName");
			responseObj.setStatusCode(HttpServletResponse.SC_NOT_FOUND);
			responseObj.setDescription("User with "+username+" not found...!!!");
		}
		return responseObj;
	}

	@Override
	public ResponseObject getAllUserDetails() {
		
		List<UserDetails> userDetailsList = userRepository.findAll();
		List<UserDetailsResponseVO> userDetailsResponseVOList = new ArrayList<UserDetailsResponseVO>();
		ResponseObject responseObj = new ResponseObject();
		if(null!=userDetailsList && !userDetailsList.isEmpty()) {
			for(UserDetails user: userDetailsList) {
				userDetailsResponseVOList.add(mapper.mapDomainToResponseVo(user));
			}
			responseObj.setResultList(userDetailsResponseVOList);
		}else {
			responseObj.setErrorCode("noContentFound");
			responseObj.setStatusCode(HttpServletResponse.SC_NO_CONTENT);
			responseObj.setDescription("No user details available in the system...!!!");
		}
		return responseObj;
	}
	
	
	

}
