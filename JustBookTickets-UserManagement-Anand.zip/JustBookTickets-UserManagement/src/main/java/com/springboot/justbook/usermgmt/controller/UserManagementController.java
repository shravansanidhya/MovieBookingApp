/**
 * 
 */
package com.springboot.justbook.usermgmt.controller;

import java.net.URI;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.springboot.justbook.usermgmt.service.UserMgmtService;
import com.springboot.justbook.usermgmt.vo.ResponseObject;
import com.springboot.justbook.usermgmt.vo.UserDetailsRequestVO;

/**
 * @author M1006601
 *
 */
@RestController
public class UserManagementController {
	
	@Autowired
	UserMgmtService userMgmtService;
	
	static Logger LOGGER = LoggerFactory.getLogger(UserManagementController.class);
	
	@PostMapping(path="/registerUser", consumes="application/json")
	public ResponseEntity<ResponseObject> registerUser(@Valid @RequestBody UserDetailsRequestVO user, HttpServletResponse response) throws Exception{
		
		LOGGER.debug("Entering Create endpoint(POST) to register user information of:", user);
		ResponseEntity<ResponseObject> responseObj = null;
		ResponseObject responseObject = new ResponseObject(); 
		responseObject=userMgmtService.addNewUser(user);
		switch (responseObject.getStatusCode()) {
		case HttpServletResponse.SC_BAD_REQUEST:
			responseObj = new ResponseEntity<ResponseObject>(responseObject, HttpStatus.BAD_REQUEST);
			break;
		default:
			URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
					.buildAndExpand(responseObject.getId()).toUri();
			response.setHeader("Location", location.toString());
			responseObj = new ResponseEntity<ResponseObject>(responseObject, HttpStatus.CREATED);
		}
		LOGGER.debug("Exiting Create endpoint(POST) to register user information:");
		return responseObj;
	}
	
	@GetMapping(path="/fetchUser/{username}", produces="application/json")
	public ResponseEntity<ResponseObject> getUserDetailsByUserName(@PathVariable("username") String username) throws Exception{
		
		LOGGER.debug("Entering fetch endpoint(GET) to get the user information details of:", username);
		ResponseEntity<ResponseObject> responseObj = null;
		ResponseObject responseObject = new ResponseObject();
		responseObject=userMgmtService.getUserDetails(username);
		switch (responseObject.getStatusCode()) {
		case HttpServletResponse.SC_NOT_FOUND:
			responseObj = new ResponseEntity<ResponseObject>(responseObject, HttpStatus.NOT_FOUND);
			break;
		default:
			responseObj = new ResponseEntity<ResponseObject>(responseObject, HttpStatus.OK);
		}
		LOGGER.debug("Exiting fetch endpoint(GET) to get the user information details of:", username);
		return responseObj;
	}
	
	@GetMapping(path="/fetchUsers", produces="application/json")
	public ResponseEntity<ResponseObject> getUserDetails() throws Exception{
		
		LOGGER.debug("Entering fetch endpoint(GET) to get all the users information details");
		ResponseEntity<ResponseObject> responseObj = null;
		ResponseObject responseObject = new ResponseObject();
		responseObject=userMgmtService.getAllUserDetails();
		switch (responseObject.getStatusCode()) {
		case HttpServletResponse.SC_NO_CONTENT:
			responseObj = new ResponseEntity<ResponseObject>(responseObject, HttpStatus.NO_CONTENT);
			break;
		default:
			responseObj = new ResponseEntity<ResponseObject>(responseObject, HttpStatus.OK);
		}
		LOGGER.debug("Exiting fetch endpoint(GET) to get all the users information details");
		return responseObj;
	}
	

}
