/**
 * 
 */
package com.springboot.justbook.usermgmt.service;

import javax.validation.Valid;

import com.springboot.justbook.usermgmt.vo.ResponseObject;
import com.springboot.justbook.usermgmt.vo.UserDetailsRequestVO;

/**
 * @author M1006601
 *
 */
public interface UserMgmtService {

	ResponseObject addNewUser(@Valid UserDetailsRequestVO user) throws Exception ;

	ResponseObject getUserDetails(String username);

	ResponseObject getAllUserDetails();
	
	

}
