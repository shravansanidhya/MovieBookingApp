package com.springboot.justbook.usermgmt.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.springboot.justbook.usermgmt.domain.UserDetails;
import com.springboot.justbook.usermgmt.mapper.UserMgmtMapper;
import com.springboot.justbook.usermgmt.repository.UserMgmtRepository;
import com.springboot.justbook.usermgmt.service.UserMgmtService;
import com.springboot.justbook.usermgmt.vo.ResponseObject;
import com.springboot.justbook.usermgmt.vo.UserDetailsRequestVO;
import com.springboot.justbook.usermgmt.vo.UserDetailsResponseVO;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@AutoConfigureWebMvc
public class UserManagementControllerTests {
	
	@InjectMocks
	UserManagementController userManagementController;
	
	@Autowired
	UserMgmtService userMgmtService;
	
	@Mock
	UserMgmtRepository userRepository;
	
	@Mock
	HttpServletResponse response;
	
	@Mock
	UserMgmtMapper mapper;
	
	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(userManagementController, "userMgmtService", userMgmtService);
		ReflectionTestUtils.setField(userMgmtService, "userRepository", userRepository);
		ReflectionTestUtils.setField(userMgmtService, "mapper", mapper);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRegisterUser() throws Exception {
		
		MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        
		UserDetailsRequestVO userRequestVO = new UserDetailsRequestVO("Arvind", "Akash", "arv.akash",
				"arvind.akash@yahoo.co.in", "akash4all$", "9941428823", "Neville Tower, TRIL Apartments, Chennai-113");
		UserDetails user = new UserDetails(Long.valueOf(1),"Arvind", "Akash", "arv.akash",
				"arvind.akash@yahoo.co.in", "akash4all$", "9941428823", "Neville Tower, TRIL Apartments, Chennai-113");
		UserDetailsResponseVO userResponse = new UserDetailsResponseVO("arv.akash","arvind.akash@yahoo.co.in", "9941428823", "akash4all$", Long.valueOf(1));
		Mockito.when(userRepository.findbyUserNameAndEmail(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(null);
		Mockito.when(mapper.mapRequestVOToDomain(userRequestVO)).thenReturn(user);
		Mockito.when(mapper.mapDomainToResponseVo(user)).thenReturn(userResponse);
		Mockito.when(userRepository.save(user)).thenReturn(user);
		ResponseEntity<ResponseObject> registerUser = userManagementController.registerUser(userRequestVO, response);
		assertNotNull(registerUser);
        assertThat(registerUser.getStatusCode()).isEqualTo(HttpStatus.CREATED);
		
	}

	@Test
	public void testGetUserDetailsByUserName() throws Exception {
		
		UserDetails user = new UserDetails(Long.valueOf(1),"Arvind", "Akash", "arv.akash",
				"arvind.akash@yahoo.co.in", "akash4all$", "9941428823", "Neville Tower, TRIL Apartments, Chennai-113");
		UserDetailsResponseVO userResponse = new UserDetailsResponseVO("arv.akash","arvind.akash@yahoo.co.in", "9941428823", "akash4all$", Long.valueOf(1));
		Mockito.when(userRepository.findbyUserName(ArgumentMatchers.anyString())).thenReturn(user);
		Mockito.when(mapper.mapDomainToResponseVo(user)).thenReturn(userResponse);
		ResponseEntity<ResponseObject> userDetailsByUserName = userManagementController.getUserDetailsByUserName("arv.akash");
		assertNotNull(userDetailsByUserName);
		UserDetailsResponseVO userRes = userDetailsByUserName.getBody().getResultList().get(0);
		assertThat(userRes.getUserDetailsPhoneNo()).isEqualTo("9941428823");
	}

	@Test
	public void testGetUserDetails() throws Exception {
		
		List<UserDetails> userList = Arrays.asList(
				new UserDetails(Long.valueOf(1),"Arvind", "Akash", "arv.akash",
				"arvind.akash@yahoo.co.in", "akash4all$", "9941428823", "13,Neville Tower, TRIL Apartments, Chennai-113"),
				new UserDetails(Long.valueOf(2),"Andrea", "Jeremiah", "iamandreajeremiah",
						"iamandreajeremiah@yahoo.co.in", "andrea4all$", "9600124522", "12-B,Neville Tower, TRIL Apartments, Chennai-113"),
				new UserDetails(Long.valueOf(3),"Poonam Amarjit Singh", "Bajwa", "bajwapoonam",
						"bajwapoonam@yahoo.co.in", "bajwa4me$", "8608136918", "Tulip Towers, Majestic Apartments, Chennai-42"));
		Mockito.when(userRepository.findAll()).thenReturn(userList);
		ResponseEntity<ResponseObject> userDetails = userManagementController.getUserDetails();
		//UserDetailsResponseVO userRes = userDetails.getBody().getResultList().get(2);
		assertNotNull(userDetails);
		//assertThat(userRes.getUserDetailsEmail()).isEqualTo("bajwapoonam@yahoo.co.in");
		//assertThat(userRes.getUserDetailsUserName()).isEqualTo("bajwapoonam");
		}

}
