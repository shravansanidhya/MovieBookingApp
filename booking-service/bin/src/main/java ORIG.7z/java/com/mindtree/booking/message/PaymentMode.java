package com.mindtree.booking.message;

public enum PaymentMode {

	DEBIT_CARD("Debit Card"), CREDIT_CARD("Credit Card"), UPI("UPI"), PAYTM("PAYTM");

	private String mode;

	private PaymentMode(String mode) {
		this.mode = mode;
	}

	public String getMode(String mode) {
		return this.mode;
	}

}
