package com.mindtree.booking.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.booking.exception.BookingNotFoundException;
import com.mindtree.booking.vo.Error;
import com.mindtree.booking.vo.ResponseObject;

@RestControllerAdvice
public class ExceptionController {

	@ExceptionHandler(BookingNotFoundException.class)
	public ResponseObject<Object> bookingNotFound(BookingNotFoundException e) {
		ResponseObject<Object> response = new ResponseObject<>();
		response.setData(null);
		response.setStatusCode(HttpStatus.NOT_FOUND.value());
		response.setUserMessage("No Booking Found!");
		response.setError(new Error(e.getMessage(), e.getMessage()));
		return response;
	}

}
