//package com.mindtree.user.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.mindtree.user.entity.Location;
//
//public interface LocationRepository extends JpaRepository<Location, Long> {
//
//}
