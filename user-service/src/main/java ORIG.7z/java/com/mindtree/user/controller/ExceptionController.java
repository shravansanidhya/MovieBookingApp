package com.mindtree.user.controller;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.user.exception.DuplicateExcepiton;
import com.mindtree.user.exception.NoUsersException;
import com.mindtree.user.exception.NotFoundException;
import com.mindtree.user.vo.Error;
import com.mindtree.user.vo.ResponseObject;

@RestControllerAdvice
public class ExceptionController {

	@ExceptionHandler(DuplicateExcepiton.class)
	public ResponseObject<Object> duplicateUserException(DuplicateExcepiton e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return new ResponseObject<Object>(HttpStatus.BAD_REQUEST.value(), "User Already Exists", null, new Error(sw.toString(), e.getMessage()));
	}
	
	@ExceptionHandler(NotFoundException.class)
	public ResponseObject<Object> noUserFoundException(NotFoundException e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return new ResponseObject<Object>(HttpStatus.BAD_REQUEST.value(), "User Does Not Exist", null, new Error(sw.toString(), e.getMessage()));
	}
	
	@ExceptionHandler(NoUsersException.class)
	public ResponseObject<Object> noUserFoundException(NoUsersException e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return new ResponseObject<Object>(HttpStatus.BAD_REQUEST.value(), "User Database Is Empty", null, new Error(sw.toString(), e.getMessage()));
	}

}
