package com.mindtree.user.exception;

/**
 * @author M1049008
 *
 */
public class DuplicateExcepiton extends UserManagementException {

	private static final long serialVersionUID = 470662028081511858L;

	public DuplicateExcepiton() {
		super();
	}

	public DuplicateExcepiton(String message) {
		super(message);
	}
	
	

}
